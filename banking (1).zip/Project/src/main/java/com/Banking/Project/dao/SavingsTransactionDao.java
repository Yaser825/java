package com.Banking.Project.dao;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;


public interface SavingsTransactionDao extends JpaRepository<SavingsTransactionDao, Long> {

    List<SavingsTransactionDao> findAll();
}
