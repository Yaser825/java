package com.Banking.Project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.Banking.Project.dao.PrimaryAccountDao;
import com.Banking.Project.entity.PrimaryAccount;
import com.Banking.Project.service.AccountService;



@RestController
@RequestMapping("/api")
public class AccountController {
	@Autowired(required = true)
	public AccountService userservice;
	@Autowired
	public AccountConverter accountconverter;
	
	@PostMapping("/createAccount")
	public String createAccount(@RequestBody PrimaryAccountDao primaryaccountdao) {
		final Account= Accountconverter.convertToEntity(PrimaryAccountDao);
		return userservice.createAccount(account);
		
		@PutMapping("/updateAccount/{identity}")
		public PrimaryAccountDao updateAccount(@PathVariable("identity") int id, @RequestBody PrimaryAccountDao primaryaccountdao) {
			Account account = Accountconverter.convertToEntity(PrimaryAccountDao);
			return userservice.updateAccount(id, account);
		

			@GetMapping("/getAccountByID/{identity}")
			public PrimaryAccountDao getAccountById(@PathVariable("identity") int id) {

				return userservice.getAccountById(id);
			}

			@DeleteMapping("/deleteAccountById/{id}")
			public String deleteAccountById(@PathVariable("id") int id) {
				return userservice.deleteAccountById(id);

			}
			@DeleteMapping("/deleteAllAccount")
			public void deleteAllAccount() {
				userservice.deleteAllAccount();
			}
	}
