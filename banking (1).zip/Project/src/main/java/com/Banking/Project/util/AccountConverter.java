package com.Banking.Project.util;


import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.Banking.Project.dao.PrimaryAccountDao;
import com.Banking.Project.entity.PrimaryAccount;

@Component
public class AccountConverter {
	
	public PrimaryAccount convertToEntity(PrimaryAccountDao Primaryaccountdao ) {
		PrimaryAccount account= new PrimaryAccount();
		if ( PrimaryAccountDao != null) {
			BeanUtils.copyProperties(PrimaryAccountDao , account);
		}
		return account;
	}
	
	public static  PrimaryAccountDao convertToPrimaryAccountDao account) {
		PrimaryAccountDao Primaryaccountdao = new PrimaryAccountDao();
		if (account= null) {
			BeanUtils.copyProperties(account,Primaryaccountdao );
		}
		return Primaryaccountdao ;

	}
}
