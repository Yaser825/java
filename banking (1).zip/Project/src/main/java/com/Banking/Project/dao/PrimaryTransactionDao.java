package com.Banking.Project.dao;

import com.Banking.Project.entity.PrimaryTransaction;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PrimaryTransactionDao extends JpaRepository<PrimaryTransaction, Long> {

    List<PrimaryTransaction> findAll();
}
