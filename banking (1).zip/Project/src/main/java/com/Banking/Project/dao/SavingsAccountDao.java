package com.Banking.Project.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Banking.Project.entity.SavingsAccount;

public interface SavingsAccountDao extends JpaRepository<SavingsAccount, Long> {

    SavingsAccount findByAccountNumber (int accountNumber);
}