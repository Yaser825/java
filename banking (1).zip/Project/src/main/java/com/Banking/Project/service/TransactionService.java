package com.Banking.Project.service;



import java.util.List;

import com.Banking.Project.entity.SavingsTransaction;
import com.Banking.Project.entity.PrimaryAccount;
import com.Banking.Project.entity.PrimaryTransaction;
import com.Banking.Project.entity.SavingsAccount;

public interface TransactionService {
	
	List<PrimaryTransaction> findPrimaryTransactionList(String username);

    List<SavingsTransaction> findSavingsTransactionList(String username);

    void savePrimaryDepositTransaction(PrimaryTransaction primaryTransaction);

    void saveSavingsDepositTransaction(SavingsTransaction savingsTransaction);
    
    void savePrimaryWithdrawTransaction(PrimaryTransaction primaryTransaction);
    
    void saveSavingsWithdrawTransaction(SavingsTransaction savingsTransaction);
    

}