package com.Banking.Project.service;
import java.security.Principal;

import com.Banking.Project.entity.PrimaryAccount;

import com.Banking.Project.entity.SavingsAccount;


public interface AccountService{
	@SuppressWarnings("rawtypes")
	PrimaryAccount createPrimaryAccount();
    SavingsAccount createSavingsAccount();
    void deposit(String accountType, double amount, Principal principal);
    void withdraw(String accountType, double amount, Principal principal);
    
    
}