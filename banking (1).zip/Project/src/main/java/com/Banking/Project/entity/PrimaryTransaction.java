package com.Banking.Project.entity;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import lombok.Builder;
 
@Entity
public class PrimaryTransaction {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private double amount;
    private long availableBalance;
    public PrimaryTransaction() {
    	
    }
    @OneToOne(cascade = { CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH }, fetch = FetchType.LAZY)
    private PrimaryTransaction primarytransaction;

	@Builder
	public PrimaryTransaction(int id, double amount, long availableBalance) {
		super();
		this.id = id;
		this.amount = amount;
		this.availableBalance = availableBalance;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public long getAvailableBalance() {
		return availableBalance;
	}

	public void setAvailableBalance(long availableBalance) {
		this.availableBalance = availableBalance;
	}

	public PrimaryTransaction getPrimarytransaction() {
		return primarytransaction;
	}

	public void setPrimarytransaction(PrimaryTransaction primarytransaction) {
		this.primarytransaction = primarytransaction;
	}
}
	  
	