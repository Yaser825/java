package com.Banking.Project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Banking.Project.dao.PrimaryTransactionDao;
import com.Banking.Project.service.TransactionService;
import com.Banking.Project.entity.SavingsTransaction;



@RestController
@RequestMapping("/api")
public class TransactionController {
	@Autowired(required = true)
	public TransactionService userservice;
	@Autowired
	public TransactionConverter transactionconverter;
	
	@PostMapping("/createTransaction")
	public String createTransaction(@RequestBody PrimaryTransactiontDao primarytransactiondao) {
		final Transaction= Transactionconverter.convertToEntity(PrimaryTransactionDao);
		return userservice.createTransaction(transaction);
		
		@PutMapping("/updateTransaction/{identity}")
		public PrimaryTransactiontDao updateTransaction(@PathVariable("identity") int id, @RequestBody PrimaryTransactionDao primarytransactiondao) {
			Transaction transaction = Transactionconverter.convertToEntity(PrimaryTransactionDao);
			return userservice.updateTransaction(id, Transaction);
		


			@GetMapping("/getTransactionByID/{identity}")
			public PrimaryTransactionDao getTransactionById(@PathVariable("identity") int id) {

				return userservice.getTransactionById(id);
			}
			
			DeleteMapping("/deleteTransactionById/{id}")
			public String deleteTransactionById(@PathVariable("id") int id) {
				return userservice.deleteTransactionById(id);

			}
			@DeleteMapping("/deleteAllTransaction")
			public void deleteAllTransaction() {
				userservice.deleteAllTransaction();
			}
}
